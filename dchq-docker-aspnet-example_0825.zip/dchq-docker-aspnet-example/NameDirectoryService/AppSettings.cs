﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NameDirectoryService
{
    public class ConnectionSettings
    {
        public string DefaultConnection { get; set; }
        public string DriverClassName { get; set; }
        
    }
}
